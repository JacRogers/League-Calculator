from tkinter import*
class ChooseChampion:
    def __init__(self):

        window1=Tk() 
        window1.geometry("1920x1080+-10+0")
        window1.title("Choose a Champion")

        def aatroxcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Aatrox"
            health = float(2025)
            attackd = float(114.776)
            attacks = float(0.983)
            move = float(345)
            healthr = float(15.09)
            armor = float(88.984)
            magic = float(53.35)
        
        def ahricommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name = "Ahri"
            health= float(1874.4)
            attackd=float(114.776)
            attacks=float(0.896)
            move=float(330)
            healthr=float(16.708)
            armor=float(80.38)
            magic=float(38.5)

        def akalicommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Akali"
            health=float(2032.8)
            attackd=float(112.776)
            attacks=float(1.06)
            move=float(350)
            healthr=float(19.392)
            armor=float(85.88)
            magic=float(53.35)

        def alistarcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Alistar"
            health=float(2415.36)
            attackd=float(122.6516)
            attacks=float(0.851)
            move=float(330)
            healthr=float(23.128)
            armor=float(83.88)
            magic=float(53.35)

        def amumucommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Amumu"
            health=float(2041.12)
            attackd=float(117.984)
            attacks=float(0.874)
            move=float(335)
            healthr=float(23.328)
            armor=float(88.144)
            magic=float(53.35)
        
        def aniviacommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Anivia"
            health=float(1657.6)
            attackd=float(105.776)
            attacks=float(0.804)
            move=float(325)
            healthr=float(14.924)
            armor=float(89.22)
            magic=float(38.5)

        def anniecommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Annie"
            health=float(1803.68)
            attackd=float(95.035)
            attacks=float(0.713)
            move=float(335)
            healthr=float(14.774)
            armor=float(87.22)
            magic=float(38.5)
        
        def aurelionsolcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Aurelion Sol"
            health=float(1910)
            attackd=float(114.4)
            attacks=float(0.77)
            move=float(325)
            healthr=float(16.7)
            armor=float(80.2)
            magic=float(38.5)

        def azircommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Azir"
            health=float(1900)
            attackd=float(99.6)
            attacks=float(0.8)
            move=float(335)
            healthr=float(16.25)
            armor=float(70.04)
            magic=float(38.5)

        def bardcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Bard"
            health=float(2048)
            attackd=float(103)
            attacks=float(0.838)
            move=float(330)
            healthr=float(14.75)
            armor=float(93)
            magic=float(38.5)

        def blitzcrankcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Blitzcrank"
            health=float(2197.6)
            attackd=float(121.04)
            attacks=float(0.745)
            move=float(325)
            healthr=float(21.26)
            armor=float(92.38)
            magic=float(53.35)

        def brandcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Brand"
            health=float(1799.68)
            attackd=float(108.04)
            attacks=float(0.77)
            move=float(340)
            healthr=float(14.774)
            armor=float(81.38)
            magic=float(38.5)
        #AT THIS POINT, THE BUTTONS BEGIN TO APPEAR OFF SCREEN FOR ME!!!

        def braumcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Braum"
            health=float(2055.16)
            attackd=float(109.776)
            attacks=float(1.028)
            move=float(335)
            healthr=float(25.18)
            armor=float(103.22)
            magic=float(53.35)

        def caitlyncommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Caityln"
            health=float(1920)
            attackd=float(90.72)
            attacks=float(0.955)
            move=float(325)
            healthr=float(15)
            armor=float(82.38)
            magic=float(38.5)

        def camillecommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Camille"
            health=float(2020.6)
            attackd=float(119.5)
            attacks=float(0.891)
            move=float(340)
            healthr=float(22.1)
            armor=float(90.6)
            magic=float(53.35)

        def cassiopeiacommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Cassiopeia"
            health=float(1800)
            attackd=float(104)
            attacks=float(0.812)
            move=float(328)
            healthr=float(14)
            armor=float(84.5)
            magic=float(38.5)

        def chogathcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Chogath"
            health=float(1934.4)
            attackd=float(132.556)
            attacks=float(0.778)
            move=float(345)
            healthr=float(23.378)
            armor=float(88.38)
            magic=float(53.35)
        
        def corkicommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Corki"
            health=float(1906.76)
            attackd=float(114.5)
            attacks=float(0.869)
            move=float(325)
            healthr=float(14.774)
            armor=float(82.88)
            magic=float(38.5)

        def dariuscommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Darius"
            health=float(2282.24)
            attackd=float(141)
            attacks=float(0.731)
            move=float(340)
            healthr=float(25.99)
            armor=float(98)
            magic=float(53.35)

        def dianacommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Diana"
            health=float(2119.2)
            attackd=float(104.04)
            attacks=float(0.864)
            move=float(345)
            healthr=float(21.878)
            armor=float(87.248)
            magic=float(53.35)

        def drmundocommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Dr. Mundo"
            health=float(2095.52)
            attackd=float(120.77)
            attacks=float(0.923)
            move=float(345)
            healthr=float(20.51)
            armor=float(86.38)
            magic=float(53.35)

        def dravencommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Draven"
            health=float(1951.76)
            attackd=float(105.27)
            attacks=float(0.991)
            move=float(330)
            healthr=float(18.076)
            armor=float(81.644)
            magic=float(38.5)
            
        def ekkocommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Ekko"
            health=float(1940)
            attackd=float(106)
            attacks=float(0.976)
            move=float(340)
            healthr=float(24.3)
            armor=float(78)
            magic=float(53.35)

        def elisecommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Elise"
            health=float(1889.4)
            attackd=float(98)
            attacks=float(0.811)
            move=float(325)
            healthr=float(15.908)
            armor=float(79.078)
            magic=float(38.5)

        def evelynncommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Evelynn"
            health=float(2000)
            attackd=float(112)
            attacks=float(0.848)
            move=float(335)
            healthr=float(21.25)
            armor=float(87.5)
            magic=float(53.35)

        def ezrealcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Ezreal"
            health=float(1844.4)
            attackd=float(96.63)
            attacks=float(0.923)
            move=float(325)
            healthr=float(15.774)
            armor=float(81.38)
            magic=float(38.5)

        def fiddlestickscommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Fiddlesticks"
            health=float(1884.4)
            attackd=float(92.985)
            attacks=float(0.848)
            move=float(335)
            healthr=float(15.808)
            armor=float(80.38)
            magic=float(38.5)

        def fioracommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Fiora"
            health=float(1995)
            attackd=float(116.1)
            attacks=float(0.965)
            move=float(345)
            healthr=float(17.6)
            armor=float(83.5)
            magic=float(53.35)

        def fizzcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Fizz"
            health=float(2020.48)
            attackd=float(109.04)
            attacks=float(1.005)
            move=float(335)
            healthr=float(20.076)
            armor=float(80.212)
            magic=float(53.35)

        def galiocommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Galio"
            health=float(2250)
            attackd=float(118.5)
            attacks=float(0.784)
            move=float(335)
            healthr=float(21.6)
            armor=float(83.5)
            magic=float(53.35)

        def gangplankcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Gangplank"
            health=float(1934)
            attackd=float(107)
            attacks=float(0.965)
            move=float(345)
            healthr=float(16.2)
            armor=float(77)
            magic=float(53.35)

        def garencommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Garen"
            health=float(2048.53)
            attackd=float(134.38)
            attacks=float(0.933)
            move=float(340)
            healthr=float(16.34)
            armor=float(78.536)
            magic=float(53.35)

        def gnarcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Gnar"
            health=float(1615)
            attackd=float(102)
            attacks=float(1.263)
            move=float(335)
            healthr=float(34.25)
            armor=float(65.5)
            magic=float(38.5)

        def gragascommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Gragas"
            health=float(2096.52)
            attackd=float(120.88)
            attacks=float(0.878)
            move=float(330)
            healthr=float(14)
            armor=float(87.25)
            magic=float(53.35)

        def gravescommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Graves"
            health=float(1979.12)
            attackd=float(101.8)
            attacks=float(0.693)
            move=float(340)
            healthr=float(19.9)
            armor=float(82.176)
            magic=float(38.5)

        def hecarimcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Hecarim"
            health=float(2110.6)
            attackd=float(112.4)
            attacks=float(0.955)
            move=float(345)
            healthr=float(19.75)
            armor=float(94.72)
            magic=float(53.35)

        def heimerdingercommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Heimerdinger"
            health=float(1751)
            attackd=float(101.436)
            attacks=float(0.77)
            move=float(340)
            healthr=float(16.35)
            armor=float(70.04)
            magic=float(38.5)

        def illaoicommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Illaoi"
            health=float(2200.6)
            attackd=float(145)
            attacks=float(0.891)
            move=float(340)
            healthr=float(23.1)
            armor=float(90.6)
            magic=float(53.35)

        def ireliacommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Irelia"
            health=float(2137.2)
            attackd=float(117.644)
            attacks=float(1.027)
            move=float(345)
            healthr=float(19.642)
            armor=float(97.75)
            magic=float(53.35)
            
        def iverncommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Ivern"
            health=float(2110)
            attackd=float(101)
            attacks=float(1.017)
            move=float(325)
            healthr=float(21.35)
            armor=float(86.5)
            magic=float(53.35)

        def jannacommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Janna"
            health=float(1690)
            attackd=float(71.5)
            attacks=float(0.938)
            move=float(320)
            healthr=float(14.774)
            armor=float(92.6)
            magic=float(38.5)
            
        def jarvanivcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Jarvan IV"
            health=float(2101.2)
            attackd=float(113.512)
            attacks=float(0.938)
            move=float(340)
            healthr=float(20.076)
            armor=float(99.2)
            magic=float(53.35)

        def jaxcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Jax"
            health=float(2037.8)
            attackd=float(119.345)
            attacks=float(1.006)
            move=float(350)
            healthr=float(17.72)
            armor=float(87)
            magic=float(53.35)

        def jaycecommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Jayce"
            health=float(2101.2)
            attackd=float(109.88)
            attacks=float(0.993)
            move=float(335)
            healthr=float(20.944)
            armor=float(86.5)
            magic=float(38.5)

        def jhincommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Jhin"
            health=float(1985)
            attackd=float(121)
            attacks=float(0.944)
            move=float(330)
            healthr=float(15.35)
            armor=float(88.5)
            magic=float(38.5)

        def jinxcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Jinx"
            health=float(1911.76)
            attackd=float(99.43)
            attacks=float(0.731)
            move=float(325)
            healthr=float(14.34)
            armor=float(91.5)
            magic=float(38.5)

        def kalistacommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Kalista"
            health=float(1928.76)
            attackd=float(112.39)
            attacks=float(0.99)
            move=float(325)
            healthr=float(15.35)
            armor=float(87.5)
            magic=float(38.5)

        def karmacommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Karma"
            health=float(1933.44)
            attackd=float(109.644)
            attacks=float(0.869)
            move=float(335)
            healthr=float(14.97)
            armor=float(84.984)
            magic=float(38.5)

        def karthuscommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Karthus"
            health=float(1791)
            attackd=float(100.91)
            attacks=float(0.849)
            move=float(335)
            healthr=float(15.77)
            armor=float(80.38)
            magic=float(38.5)

        def kassandincommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Kassadin"
            health=float(1890.04)
            attackd=float(125.152)
            attacks=float(1.042)
            move=float(340)
            healthr=float(16.29)
            armor=float(77.776)
            magic=float(38.5)

        def katrinacommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Katrina"
            health=float(1984)
            attackd=float(112.4)
            attacks=float(0.964)
            move=float(340)
            healthr=float(19.4)
            armor=float(87.38)
            magic=float(53.35)

        def kaylecommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Kayle"
            health=float(2155.24)
            attackd=float(98.604)
            attacks=float(0.876)
            move=float(335)
            healthr=float(21.01)
            armor=float(86.38)
            magic=float(38.5)

        def kayncommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Kayn"
            health=float(2030)
            attackd=float(107.6)
            attacks=float(0.912)
            move=float(340)
            healthr=float(20.75)
            armor=float(94.1)
            magic=float(53.35)

        def kennencommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Kennen"
            health=float(1878.72)
            attackd=float(106.644)
            attacks=float(1.089)
            move=float(335)
            healthr=float(16.64)
            armor=float(99.75)
            magic=float(38.5)

        def khazixcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Khazix"
            health=float(2017.8)
            attackd=float(107.908)
            attacks=float(0.975)
            move=float(350)
            healthr=float(20.26)
            armor=float(87)
            magic=float(53.35)

        def kindredcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Kindred"
            health=float(1985)
            attackd=float(95.42)
            attacks=float(0.891)
            move=float(325)
            healthr=float(16.35)
            armor=float(88.5)
            magic=float(38.5)

        def kledcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Kled"
            health=float(1530)
            attackd=float(106)
            attacks=float(0.997)
            move=float(345)
            healthr=float(18.75)
            armor=float(103)
            magic=float(53.35)

        def kogmawcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Kog Maw"
            health=float(1911.76)
            attackd=float(98.43)
            attacks=float(0.964)
            move=float(325)
            healthr=float(15.27)
            armor=float(88.5)
            magic=float(38.5)
            
        def leblanccommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Leblan"
            health=float(1876)
            attackd=float(114.38)
            attacks=float(0.774)
            move=float(340)
            healthr=float(16.75)
            armor=float(81.38)
            magic=float(38.5)

        def leesincommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Les Sin"
            health=float(2015.8)
            attackd=float(115.576)
            attacks=float(0.983)
            move=float(345)
            healthr=float(19.325)
            armor=float(95.9)
            magic=float(53.35)

        def leonacommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Leona"
            health=float(2055.16)
            attackd=float(111.04)
            attacks=float(0.933)
            move=float(335)
            healthr=float(22.875)
            armor=float(108.2)
            magic=float(53.35)
            
        def lissandracommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Lissandra"
            health=float(1781.12)
            attackd=float(98.9)
            attacks=float(0.77)
            move=float(325)
            healthr=float(16.27)
            armor=float(83.116)
            magic=float(38.5)

        def luciancommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Lucian"
            health=float(1914.4)
            attackd=float(98.43)
            attacks=float(0.996)
            move=float(335)
            healthr=float(17.24)
            armor=float(84)
            magic=float(38.5)

        def lulucommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Lulu"
            health=float(1783)
            attackd=float(90.568)
            attacks=float(0.864)
            move=float(330)
            healthr=float(16.205)
            armor=float(90.9)
            magic=float(38.5)

        def luxcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Lux"
            health=float(1820.72)
            attackd=float(109.644)
            attacks=float(0.77)
            move=float(330)
            healthr=float(14.774)
            armor=float(86.72)
            magic=float(38.5)

        def malphitecommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Malphite"
            health=float(2104.2)
            attackd=float(119.345)
            attacks=float(1.006)
            move=float(335)
            healthr=float(16.35)
            armor=float(100.75)
            magic=float(53.35)

        def malzaharcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Malphite"
            health=float(1800)
            attackd=float(106)
            attacks=float(0.784)
            move=float(335)
            healthr=float(16.2)
            armor=float(77.5)
            magic=float(38.5)

        def maokaicommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Maokai"
            health=float(2180)
            attackd=float(119.644)
            attacks=float(0.945)
            move=float(335)
            healthr=float(17.75)
            armor=float(107)
            magic=float(53.35)

        def masterycommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Master Yi"
            health=float(2162.56)
            attackd=float(111.04)
            attacks=float(0.91)
            move=float(355)
            healthr=float(18.642)
            armor=float(84)
            magic=float(53.35)

        def missfourtunecommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Miss Fourtune"
            health=float(1975)
            attackd=float(63)
            attacks=float(0.991)
            move=float(325)
            healthr=float(17.242)
            armor=float(84)
            magic=float(38.5)

        def mordekaisercommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Mordekaiser"
            health=float(1766)
            attackd=float(146)
            attacks=float(0.826)
            move=float(325)
            healthr=float(9.1)
            armor=float(88.75)
            magic=float(53.35)

        def morganacommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Morgana"
            health=float(2009.48)
            attackd=float(114.96)
            attacks=float(0.788)
            move=float(335)
            healthr=float(15.908)
            armor=float(89.984)
            magic=float(38.5)

        def namicommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Nami"
            health=float(1747.32)
            attackd=float(103.908)
            attacks=float(0.93)
            move=float(335)
            healthr=float(14.77)
            armor=float(97)
            magic=float(38.5)

        def nasuscommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Nasus"
            health=float(2091.2)
            attackd=float(118.68)
            attacks=float(1.015)
            move=float(350)
            healthr=float(24.31)
            armor=float(93.5)
            magic=float(53.35)

        def nautiluscommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Nautilus"
            health=float(2038.48)
            attackd=float(113.644)
            attacks=float(0.717)
            move=float(325)
            healthr=float(17.72)
            armor=float(98.75)
            magic=float(53.35)

        def nidaleecommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Nidalee"
            health=float(1900)
            attackd=float(112.5)
            attacks=float(0.987)
            move=float(335)
            healthr=float(16.205)
            armor=float(87.5)
            magic=float(38.5)

        def nocturnecommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Nocturne"
            health=float(2027.8)
            attackd=float(111.908)
            attacks=float(0.975)
            move=float(345)
            healthr=float(21.01)
            armor=float(98.5)
            magic=float(53.35)

        def nunucommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Nunu"
            health=float(1980)
            attackd=float(127)
            attacks=float(0.864)
            move=float(345)
            healthr=float(18.6)
            armor=float(87.5)
            magic=float(53.35)

        def olafcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Olaf"
            health=float(2178.24)
            attackd=float(119.48)
            attacks=float(1.013)
            move=float(350)
            healthr=float(23.81)
            armor=float(86)
            magic=float(53.35)

        def oriannacommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Orianna"
            health=float(1860.72)
            attackd=float(84.568)
            attacks=float(1.049)
            move=float(325)
            healthr=float(16.22)
            armor=float(68.04)
            magic=float(38.5)

        def pantheoncommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Pantheon"
            health=float(2058.16)
            attackd=float(104.872)
            attacks=float(0.967)
            move=float(335)
            healthr=float(18.892)
            armor=float(103.3)
            magic=float(53.35)

        def poppycommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Poppy"
            health=float(2070)
            attackd=float(124)
            attacks=float(0.891)
            move=float(345)
            healthr=float(21.6)
            armor=float(97.5)
            magic=float(53.35)

        def quinncommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Quinn"
            health=float(1977.8)
            attackd=float(95.43)
            attacks=float(1.021)
            move=float(335)
            healthr=float(14.774)
            armor=float(91.5)
            magic=float(38.5)

        def rakancommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Rakan"
            health=float(1955)
            attackd=float(121.5)
            attacks=float(0.944)
            move=float(335)
            healthr=float(13.5)
            armor=float(102.3)
            magic=float(38.5)

        def rammuscommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Rammus"
            health=float(2026.48)
            attackd=float(115.38)
            attacks=float(0.86)
            move=float(335)
            healthr=float(17.274)
            armor=float(113.1)
            magic=float(53.35)

        def reksaicommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Rek Sai"
            health=float(2015)
            attackd=float(113.95)
            attacks=float(0.838)
            move=float(335)
            healthr=float(18.392)
            armor=float(96.75)
            magic=float(53.35)

        def renektoncommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Renekton"
            health=float(2051.16)
            attackd=float(111.028)
            attacks=float(0.964)
            move=float(345)
            healthr=float(20.71)
            armor=float(99.6)
            magic=float(53.35)

        def rengarcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Rengar"
            health=float(2116.2)
            attackd=float(85.5)
            attacks=float(0.997)
            move=float(345)
            healthr=float(15.5)
            armor=float(85)
            magic=float(53.35)

        def rivencommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Riven"
            health=float(2020.48)
            attackd=float(107.04)
            attacks=float(0.997)
            move=float(340)
            healthr=float(13.84)
            armor=float(87.4)
            magic=float(53.35)

        def rumblecommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Rumble"
            health=float(1944.4)
            attackd=float(115.436)
            attacks=float(0.847)
            move=float(345)
            healthr=float(18.208)
            armor=float(90.38)
            magic=float(53.35)

        def ryzecommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Ryze"
            health=float(2020.48)
            attackd=float(106.04)
            attacks=float(0.849)
            move=float(340)
            healthr=float(16.35)
            armor=float(75.552)
            magic=float(38.5)

        def sejuanicommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Sejuani"
            health=float(2175)
            attackd=float(107)
            attacks=float(0.944)
            move=float(340)
            healthr=float(22.95)
            armor=float(87)
            magic=float(39.5)

        def shacocommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Shaco"
            health=float(2010.12)
            attackd=float(117.08)
            attacks=float(1.049)
            move=float(340)
            healthr=float(17.724)
            armor=float(85.5)
            magic=float(53.35)

        def shencommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Shen"
            health=float(1985)
            attackd=float(111)
            attacks=float(0.838)
            move=float(340)
            healthr=float(21.25)
            armor=float(85)
            magic=float(53.35)
            
        def shyvanacommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Shyvana"
            health=float(2209.6)
            attackd=float(118.512)
            attacks=float(0.938)
            move=float(350)
            healthr=float(22.2)
            armor=float(94.95)
            magic=float(53.35)
            
        def singedcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Singed"
            health=float(2025)
            attackd=float(119.695)
            attacks=float(0.801)
            move=float(345)
            healthr=float(17.324)
            armor=float(96.5)
            magic=float(53.35)
            
        def sioncommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Sion"
            health=float(1783.64)
            attackd=float(127.72)
            attacks=float(0.829)
            move=float(345)
            healthr=float(23.78)
            armor=float(83)
            magic=float(53.35)
            
        def sivircommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Sivir"
            health=float(1909.76)
            attackd=float(98.43)
            attacks=float(0.795)
            move=float(335)
            healthr=float(14.542)
            armor=float(86.25)
            magic=float(38.5)
            
        def skarnercommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Skarner"
            health=float(2131.28)
            attackd=float(133.5)
            attacks=float(0.848)
            move=float(335)
            healthr=float(23.378)
            armor=float(102.6)
            magic=float(53.35)
            
        def sonacommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Sona"
            health=float(1791.36)
            attackd=float(101.4)
            attacks=float(0.896)
            move=float(325)
            healthr=float(14.774)
            armor=float(84.1)
            magic=float(38.5)
            
        def sorakacommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Soraka"
            health=float(1855.04)
            attackd=float(101.4)
            attacks=float(0.852)
            move=float(325)
            healthr=float(11)
            armor=float(96.6)
            magic=float(38.5)
            
        def swaincommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Swain"
            health=float(2046.04)
            attackd=float(103.4)
            attacks=float(0.849)
            move=float(335)
            healthr=float(18.892)
            armor=float(90.72)
            magic=float(38.5)
            
        def syndracommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Syndra"
            health=float(1837.04)
            attackd=float(103.172)
            attacks=float(0.838)
            move=float(330)
            healthr=float(16.708)
            armor=float(82.512)
            magic=float(38.5)
            
        def tahmkenchcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Tahm Kench"
            health=float(2225)
            attackd=float(110.4)
            attacks=float(0.891)
            move=float(334)
            healthr=float(15.85)
            armor=float(106.5)
            magic=float(53.35)
            
        def taliyahcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Taliyah"
            health=float(1795)
            attackd=float(112.1)
            attacks=float(0.77)
            move=float(325)
            healthr=float(18.9)
            armor=float(71)
            magic=float(38.5)
            
        def taloncommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Talon"
            health=float(2112.8)
            attackd=float(112.7)
            attacks=float(0.998)
            move=float(335)
            healthr=float(21.26)
            armor=float(91.5)
            magic=float(53.35)
            
        def tariccommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Taric"
            health=float(2105)
            attackd=float(114.5)
            attacks=float(0.838)
            move=float(340)
            healthr=float(14.5)
            armor=float(102.8)
            magic=float(53.35)
            
        def teemocommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Teemo"
            health=float(1909.76)
            attackd=float(100.54)
            attacks=float(1.087)
            move=float(330)
            healthr=float(16.792)
            armor=float(88.05)
            magic=float(38.5)
            
        def threshcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Thresh"
            health=float(2141.52)
            attackd=float(85.096)
            attacks=float(0.997)
            move=float(335)
            healthr=float(16.274)
            armor=float(28)
            magic=float(38.5)
            
        def tristanacommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Tristana"
            health=float(1936.76)
            attackd=float(97.93)
            attacks=float(0.823)
            move=float(325)
            healthr=float(17.242)
            armor=float(82)
            magic=float(38.5)
            
        def trundlecommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Trundle"
            health=float(2248.28)
            attackd=float(111.04)
            attacks=float(1)
            move=float(350)
            healthr=float(18.75)
            armor=float(82.9)
            magic=float(53.35)
            
        def tryndamerecommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Tryndamere"
            health=float(2291.64)
            attackd=float(115.776)
            attacks=float(1)
            move=float(345)
            healthr=float(23.812)
            armor=float(85.7)
            magic=float(53.35)
            
        def twistedfatecommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Twisted Fate"
            health=float(1915.76)
            attackd=float(106.054)
            attacks=float(1.007)
            move=float(335)
            healthr=float(15.708)
            armor=float(74.092)
            magic=float(38.5)
            
        def twitchcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Twitch"
            health=float(1902.08)
            attackd=float(96.43)
            attacks=float(1.07)
            move=float(330)
            healthr=float(16.208)
            armor=float(83)
            magic=float(38.5)
            
        def udyrcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Udyr"
            health=float(2276.32)
            attackd=float(143.286)
            attacks=float(0.957)
            move=float(345)
            healthr=float(18.75)
            armor=float(102)
            magic=float(53.35)
            
        def urgotcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Urgot"
            health=float(2081)
            attackd=float(123)
            attacks=float(0.975)
            move=float(330)
            healthr=float(19.4)
            armor=float(111.25)
            magic=float(53.35)
            
        def varuscommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Vaurs"
            health=float(1931.76)
            attackd=float(95.63)
            attacks=float(0.993)
            move=float(330)
            healthr=float(14.774)
            armor=float(89.8)
            magic=float(38.5)
            
        def vaynecommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Vayne"
            health=float(1909.44)
            attackd=float(84.1)
            attacks=float(1.105)
            move=float(330)
            healthr=float(14.774)
            armor=float(85.8)
            magic=float(38.5)
            
        def veigarcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Veigar"
            health=float(1886.76)
            attackd=float(95.335)
            attacks=float(0.863)
            move=float(340)
            healthr=float(16.7)
            armor=float(86.3)
            magic=float(38.5)
            
        

        def buttoncommand():
            window1.destroy()
            ChooseChampion2()
            


        aatroxImage=PhotoImage(file ="Aatrox.gif")
        ahriImage=PhotoImage(file="Ahri.gif")
        akaliImage=PhotoImage(file="Akali.gif")
        alistarImage=PhotoImage(file="Alistar.gif")
        amumuImage=PhotoImage(file="Amumu.gif")
        aniviaImage=PhotoImage(file="Anivia.gif")
        annieImage=PhotoImage(file="Annie.gif")
        aurelionsolImage=PhotoImage(file="AurelionSol.gif")
        azirImage=PhotoImage(file="Azir.gif")
        bardImage=PhotoImage(file="Bard.gif")
        blitzcrankImage=PhotoImage(file="Blitzcrank.gif")
        brandImage=PhotoImage(file="Brand.gif")
        braumImage=PhotoImage(file="Braum.gif")
        caitlynImage=PhotoImage(file="Caitlyn.gif")
        camilleImage=PhotoImage(file="Camille.gif")
        cassiopeiaImage=PhotoImage(file="Cassiopeia.gif")
        chogathImage=PhotoImage(file="Chogath.gif")
        corkiImage=PhotoImage(file="Corki.gif")
        dariusImage=PhotoImage(file="Darius.gif")
        dianaImage=PhotoImage(file="Diana.gif")
        dravenImage=PhotoImage(file="Draven.gif")
        drmundoImage=PhotoImage(file="DrMundo.gif")
        ekkoImage=PhotoImage(file="Ekko.gif")
        eliseImage=PhotoImage(file="Elise.gif")
        evelynnImage=PhotoImage(file="Evelynn.gif")
        ezrealImage=PhotoImage(file="Ezreal.gif")
        fiddlesticksImage=PhotoImage(file="FiddleSticks.gif")
        fioraImage=PhotoImage(file="Fiora.gif")
        fizzImage=PhotoImage(file="Fizz.gif")
        galioImage=PhotoImage(file ="Galio.gif")
        gangplankImage=PhotoImage(file ="Gangplank.gif")
        garenImage=PhotoImage(file ="Garen.gif")
        gnarImage=PhotoImage(file ="Gnar.gif")
        gragasImage=PhotoImage(file ="Gragas.gif")
        gravesImage=PhotoImage(file ="Graves.gif")
        hecarimImage=PhotoImage(file ="Hecarim.gif")
        heimerdingerImage=PhotoImage(file ="Heimerdinger.gif")
        illaoiImage=PhotoImage(file ="Illaoi.gif")
        ireliaImage=PhotoImage(file ="irelia.gif")
        ivernImage=PhotoImage(file ="ivern.gif")
        jannaImage=PhotoImage(file ="Janna.gif")
        jarvanivImage=PhotoImage(file ="JarvanIV.gif")
        jaxImage=PhotoImage(file ="Jax.gif")
        jayceImage=PhotoImage(file ="Jayce.gif")
        jhinImage=PhotoImage(file ="Jhin.gif")
        jinxImage=PhotoImage(file ="Jinx.gif")
        kalistaImage=PhotoImage(file ="Kalista.gif")
        karmaImage=PhotoImage(file ="Karma.gif")
        karthusImage=PhotoImage(file ="Karthus.gif")
        kassadinImage=PhotoImage(file ="Kassadin.gif")
        katarinaImage=PhotoImage(file ="Katarina.gif")
        kayleImage=PhotoImage(file ="Kayle.gif")
        kaynImage=PhotoImage(file ="Kayn.gif")
        kennenImage=PhotoImage(file ="Kennen.gif")
        khazixImage=PhotoImage(file ="Khazix.gif")
        kindredImage=PhotoImage(file ="Kindred.gif")
        kledImage=PhotoImage(file ="Kled.gif")
        kogmawImage=PhotoImage(file ="KogMaw.gif")
        leblancImage=PhotoImage(file ="leblanc.gif")
        leesinImage=PhotoImage(file ="LeeSin.gif")
        leonaImage=PhotoImage(file ="Leona.gif")
        lissandraImage=PhotoImage(file ="Lissandra.gif")
        lucianImage=PhotoImage(file ="Lucian.gif")
        luluImage=PhotoImage(file ="Lulu.gif")
        luxImage=PhotoImage(file ="Lux.gif")
        malphiteImage=PhotoImage(file ="Malphite.gif")
        malzaharImage=PhotoImage(file ="Malzahar.gif")
        maokaiImage=PhotoImage(file ="Maokai.gif")
        masteryiImage=PhotoImage(file ="MasterYi.gif")
        missfortuneImage=PhotoImage(file ="MissFortune.gif")
        mordekaiserImage=PhotoImage(file ="Mordekaiser.gif")
        morganaImage=PhotoImage(file ="Morgana.gif")
        namiImage=PhotoImage(file ="Nami.gif")
        nasusImage=PhotoImage(file ="Nasus.gif")
        nautilusImage=PhotoImage(file ="Nautilus.gif")
        nidaleeImage=PhotoImage(file ="Nidalee.gif")
        nocturneImage=PhotoImage(file ="Nocturne.gif")
        nunuImage=PhotoImage(file ="Nunu.gif")
        olafImage=PhotoImage(file ="Olaf.gif")
        oriannaImage=PhotoImage(file ="Orianna.gif")
        pantheonImage=PhotoImage(file ="Pantheon.gif")
        poppyImage=PhotoImage(file ="Poppy.gif")
        quinnImage=PhotoImage(file ="Quinn.gif")
        rakanImage=PhotoImage(file ="Rakan.gif")
        rammusImage=PhotoImage(file ="Rammus.gif")
        reksaiImage=PhotoImage(file ="RekSai.gif")
        renektonImage=PhotoImage(file ="Renekton.gif")
        rengarImage=PhotoImage(file ="Rengar.gif")
        rivenImage=PhotoImage(file ="Riven.gif")
        rumbleImage=PhotoImage(file ="Rumble.gif")
        ryzeImage=PhotoImage(file ="Ryze.gif")
        sejuaniImage=PhotoImage(file ="Sejuani.gif")
        shacoImage=PhotoImage(file ="Shaco.gif")
        shenImage=PhotoImage(file ="Shen.gif")
        shyvanaImage=PhotoImage(file ="Shyvana.gif")
        singedImage=PhotoImage(file ="Singed.gif")
        sionImage=PhotoImage(file ="Sion.gif")
        sivirImage=PhotoImage(file ="Sivir.gif")
        skarnerImage=PhotoImage(file ="Skarner.gif")
        sonaImage=PhotoImage(file ="Sona.gif")
        sorakaImage=PhotoImage(file ="Soraka.gif")
        swainImage=PhotoImage(file ="Swain.gif")
        syndraImage=PhotoImage(file ="Syndra.gif")
        tahmkenchImage=PhotoImage(file ="TahmKench.gif")
        taliyahImage=PhotoImage(file ="Taliyah.gif")
        talonImage=PhotoImage(file ="Talon.gif")
        taricImage=PhotoImage(file ="Taric.gif")
        teemoImage=PhotoImage(file ="Teemo.gif")
        threshImage=PhotoImage(file ="Thresh.gif")
        tristanaImage=PhotoImage(file ="Tristana.gif")
        trundleImage=PhotoImage(file ="Trundle.gif")
        tryndamereImage=PhotoImage(file ="Tryndamere.gif")
        twistedfateImage=PhotoImage(file ="TwistedFate.gif")
        twitchImage=PhotoImage(file ="Twitch.gif")
        udyrImage=PhotoImage(file ="Udyr.gif")
        urgotImage=PhotoImage(file ="Urgot.gif")
        varusImage=PhotoImage(file ="Varus.gif")
        vayneImage=PhotoImage(file ="Vayne.gif")
        veigarImage=PhotoImage(file ="Veigar.gif")
        arrowImage=PhotoImage(file="arrow.gif")

        frame1=Frame(window1).grid()

        canv_1=Canvas(frame1, height=1020, width=1920, bg="gray").grid(row = 1, rowspan = 800, column = 1, columnspan = 1600)
    #buttonSize = window1.winfo_width()/4

        aatroxbutton=Button(window1, image=aatroxImage, command=aatroxcommand)
        aatroxbutton.grid(row = 1, column = 1)

        ahributton=Button(window1, image=ahriImage, command=ahricommand)
        ahributton.grid(row = 1, column = 2)

        akalibutton=Button(window1, image=akaliImage, command=akalicommand)
        akalibutton.grid(row = 1, column = 3)

        alistarbutton=Button(window1, image=alistarImage, command=alistarcommand)
        alistarbutton.grid(row = 1, column = 4)

        amumubutton=Button(window1, image=amumuImage, command=amumucommand)
        amumubutton.grid(row = 1, column = 5)

        aniviabutton=Button(window1, image=aniviaImage, command=aniviacommand)
        aniviabutton.grid(row = 1, column = 6)

        anniebutton=Button(window1, image=annieImage, command=anniecommand)
        anniebutton.grid(row = 1, column = 7)

        aurelionsolbutton=Button(window1, image=aurelionsolImage, command=aurelionsolcommand)
        aurelionsolbutton.grid(row = 1, column = 8)

        azirbutton=Button(window1, image=azirImage, command=azircommand)
        azirbutton.grid(row = 1, column =9)

        bardbutton=Button(window1, image=bardImage, command=bardcommand)
        bardbutton.grid(row=1, column=10)

        blitzcrankbutton=Button(window1, image=blitzcrankImage, command=blitzcrankcommand)
        blitzcrankbutton.grid(row=1, column=11)

        brandbutton=Button(window1, image=brandImage, command=brandcommand)
        brandbutton.grid(row=1, column=12)

        braumbutton=Button(window1, image=braumImage, command=braumcommand)
        braumbutton.grid(row=1, column=13)

        caitlynbutton=Button(window1, image=caitlynImage, command=caitlyncommand)
        caitlynbutton.grid(row=1, column=14)
        
        camillebutton=Button(window1, image=camilleImage, command=camillecommand)
        camillebutton.grid(row=1, column=15)

        cassiopeiabutton=Button(window1, image=cassiopeiaImage, command=cassiopeiacommand)
        cassiopeiabutton.grid(row=2, column=1)

        chogathbutton=Button(window1, image=chogathImage, command=chogathcommand)
        chogathbutton.grid(row=2, column=2)

        corkibutton=Button(window1, image=corkiImage, command=corkicommand)
        corkibutton.grid(row=2, column=3)

        dariusbutton=Button(window1, image=dariusImage, command=dariuscommand)
        dariusbutton.grid(row=2, column=4)

        dianabutton=Button(window1, image=dianaImage, command=dianacommand)
        dianabutton.grid(row=2, column=5)

        dravenbutton=Button(window1, image=dravenImage, command=dravencommand)
        dravenbutton.grid(row=2, column=6)

        drmundobutton=Button(window1, image=drmundoImage, command=drmundocommand)
        drmundobutton.grid(row=2, column=7)

        ekkobutton=Button(window1, image=ekkoImage, command=ekkocommand)
        ekkobutton.grid(row=2, column=8)

        elisebutton=Button(window1, image=eliseImage, command=elisecommand)
        elisebutton.grid(row=2, column=9)

        evelynnbutton=Button(window1, image=evelynnImage, command=evelynncommand)
        evelynnbutton.grid(row=2, column=10)

        ezrealbutton=Button(window1, image=ezrealImage, command=ezrealcommand)
        ezrealbutton.grid(row=2, column=11)

        fiddlesticksbutton=Button(window1, image=fiddlesticksImage, command=fiddlestickscommand)
        fiddlesticksbutton.grid(row=2, column=12)

        fiorabutton=Button(window1, image=fioraImage, command=fioracommand)
        fiorabutton.grid(row=2, column=13)

        fizzbutton=Button(window1, image=fizzImage, command=fizzcommand)
        fizzbutton.grid(row=2, column=14)

        galiobutton=Button(window1, image=galioImage, command=galiocommand)
        galiobutton.grid(row = 2, column = 15)

        gangplankbutton=Button(window1, image=gangplankImage, command=gangplankcommand)
        gangplankbutton.grid(row = 3, column = 1)

        garenbutton=Button(window1, image=garenImage, command=garencommand)
        garenbutton.grid(row = 3, column = 2)

        gnarbutton=Button(window1, image=gnarImage, command=gnarcommand)
        gnarbutton.grid(row = 3, column = 3)

        gragasbutton=Button(window1, image=gragasImage, command=gragascommand)
        gragasbutton.grid(row = 3, column = 4)

        gravesbutton=Button(window1, image=gravesImage, command=gravescommand)
        gravesbutton.grid(row = 3, column = 5)

        hecarimbutton=Button(window1, image=hecarimImage, command=hecarimcommand)
        hecarimbutton.grid(row = 3, column = 6)

        heimerdingerbutton=Button(window1, image=heimerdingerImage, command=heimerdingercommand)
        heimerdingerbutton.grid(row = 3, column = 7)

        illaoibutton=Button(window1, image=illaoiImage, command=illaoicommand)
        illaoibutton.grid(row = 3, column = 8)

        ireliabutton=Button(window1, image=ireliaImage, command=ireliacommand)
        ireliabutton.grid(row = 3, column = 9)

        ivernbutton=Button(window1, image=ivernImage, command=iverncommand)
        ivernbutton.grid(row = 3, column = 10)

        jannabutton=Button(window1, image=jannaImage, command=jannacommand)
        jannabutton.grid(row = 3, column = 11)

        jarvanivbutton=Button(window1, image=jarvanivImage, command=jarvanivcommand)
        jarvanivbutton.grid(row = 3, column = 12)

        jaxbutton=Button(window1, image=jaxImage, command=jaxcommand)
        jaxbutton.grid(row = 3, column = 13)

        jaycebutton=Button(window1, image=jayceImage, command=jaycecommand)
        jaycebutton.grid(row = 3, column = 14)

        jhinbutton=Button(window1, image=jhinImage, command=jhincommand)
        jhinbutton.grid(row = 3, column = 15)

        jinxbutton=Button(window1, image=jinxImage, command=jinxcommand)
        jinxbutton.grid(row = 4, column = 1)

        kalistabutton=Button(window1, image=kalistaImage, command=kalistacommand)
        kalistabutton.grid(row = 4, column = 2)

        karmabutton=Button(window1, image=karmaImage, command=karmacommand)
        karmabutton.grid(row = 4, column = 3)

        karthusbutton=Button(window1, image=karthusImage, command=karthuscommand)
        karthusbutton.grid(row = 4, column = 4)

        kassadinbutton=Button(window1, image=kassadinImage, command=kassandincommand)
        kassadinbutton.grid(row = 4, column = 5)

        katarinabutton=Button(window1, image=katarinaImage, command=katrinacommand)
        katarinabutton.grid(row = 4, column = 6)

        kaylebutton=Button(window1, image=kayleImage, command=kaylecommand)
        kaylebutton.grid(row = 4, column = 7)

        kaynbutton=Button(window1, image=kaynImage, command=kayncommand)
        kaynbutton.grid(row = 4, column = 8)

        kennenbutton=Button(window1, image=kennenImage, command=kennencommand)
        kennenbutton.grid(row = 4, column = 9)

        khazixbutton=Button(window1, image=khazixImage, command=khazixcommand)
        khazixbutton.grid(row = 4, column = 10)

        kindredbutton=Button(window1, image=kindredImage, command=kindredcommand)
        kindredbutton.grid(row = 4, column = 11)

        kledbutton=Button(window1, image=kledImage, command=kledcommand)
        kledbutton.grid(row = 4, column = 12)

        kogmawbutton=Button(window1, image=kogmawImage, command=kogmawcommand)
        kogmawbutton.grid(row = 4, column = 13)

        leblancbutton=Button(window1, image=leblancImage, command=leblanccommand)
        leblancbutton.grid(row = 4, column = 14)

        leesinbutton=Button(window1, image=leesinImage, command=leesincommand)
        leesinbutton.grid(row = 4, column = 15)

        leonabutton=Button(window1, image=leonaImage, command=leonacommand)
        leonabutton.grid(row = 5, column = 1)

        lissandrabutton=Button(window1, image=lissandraImage, command=lissandracommand)
        lissandrabutton.grid(row = 5, column = 2)

        lucianbutton=Button(window1, image=lucianImage, command=luciancommand)
        lucianbutton.grid(row = 5, column = 3)

        lulubutton=Button(window1, image=luluImage, command=lulucommand)
        lulubutton.grid(row = 5, column = 4)

        luxbutton=Button(window1, image=luxImage, command=luxcommand)
        luxbutton.grid(row = 5, column = 5)

        malphitebutton=Button(window1, image=malphiteImage, command=malphitecommand)
        malphitebutton.grid(row = 5, column = 6)

        malzaharbutton=Button(window1, image=malzaharImage, command=malzaharcommand)
        malzaharbutton.grid(row = 5, column = 7)

        maokaibutton=Button(window1, image=maokaiImage, command=maokaicommand)
        maokaibutton.grid(row = 5, column = 8)

        masteryibutton=Button(window1, image=masteryiImage, command=masterycommand)
        masteryibutton.grid(row = 5, column = 9)

        missfortunebutton=Button(window1, image=missfortuneImage, command=missfourtunecommand)
        missfortunebutton.grid(row = 5, column = 10)

        mordekaiserbutton=Button(window1, image=mordekaiserImage, command=mordekaisercommand)
        mordekaiserbutton.grid(row = 5, column = 11)

        morganabutton=Button(window1, image=morganaImage, command=morganacommand)
        morganabutton.grid(row = 5, column = 12)

        namibutton=Button(window1, image=namiImage, command=namicommand)
        namibutton.grid(row = 5, column = 13)
        
        nasusbutton=Button(window1, image=nasusImage, command=nasuscommand)
        nasusbutton.grid(row = 5, column = 14)

        nautilusbutton=Button(window1, image=nautilusImage, command=nautiluscommand)
        nautilusbutton.grid(row = 5, column = 15)
        
        nidaleebutton=Button(window1, image=nidaleeImage, command=nidaleecommand)
        nidaleebutton.grid(row = 6, column = 1)

        nocturnebutton=Button(window1, image=nocturneImage, command=nocturnecommand)
        nocturnebutton.grid(row = 6, column = 2)

        nunubutton=Button(window1, image=nunuImage, command=nunucommand)
        nunubutton.grid(row = 6, column = 3)

        olafbutton=Button(window1, image=olafImage, command=olafcommand)
        olafbutton.grid(row = 6, column = 4)

        oriannabutton=Button(window1, image=oriannaImage, command=oriannacommand)
        oriannabutton.grid(row = 6, column = 5)

        pantheonbutton=Button(window1, image=pantheonImage, command=pantheoncommand)
        pantheonbutton.grid(row = 6, column = 6)

        poppybutton=Button(window1, image=poppyImage, command=poppycommand)
        poppybutton.grid(row = 6, column = 7)

        quinnbutton=Button(window1, image=quinnImage, command=quinncommand)
        quinnbutton.grid(row = 6, column = 8)

        rakanbutton=Button(window1, image=rakanImage, command=rakancommand)
        rakanbutton.grid(row = 6, column = 9)

        rammusbutton=Button(window1, image=rammusImage, command=rammuscommand)
        rammusbutton.grid(row = 6, column = 10)

        reksaibutton=Button(window1, image=reksaiImage, command=reksaicommand)
        reksaibutton.grid(row = 6, column = 11)

        renektonbutton=Button(window1, image=renektonImage, command=renektoncommand)
        renektonbutton.grid(row = 6, column = 12)

        rengarbutton=Button(window1, image=rengarImage, command=rengarcommand)
        rengarbutton.grid(row = 6, column = 13)

        rivenbutton=Button(window1, image=rivenImage, command=rivencommand)
        rivenbutton.grid(row = 6, column = 14)

        rumblebutton=Button(window1, image=rumbleImage, command=rumblecommand)
        rumblebutton.grid(row = 6, column = 15)

        ryzebutton=Button(window1, image=ryzeImage, command=ryzecommand)
        ryzebutton.grid(row = 7, column = 1)
        
        sejuanibutton=Button(window1, image=sejuaniImage, command=sejuanicommand)
        sejuanibutton.grid(row = 7, column = 2)
        
        shacobutton=Button(window1, image=shacoImage, command=shacocommand)
        shacobutton.grid(row = 7, column = 3)

        shenbutton=Button(window1, image=shenImage, command=shencommand)
        shenbutton.grid(row = 7, column = 4)

        shyvanabutton=Button(window1, image=shyvanaImage, command=shyvanacommand)
        shyvanabutton.grid(row = 7, column = 5)

        singedbutton=Button(window1, image=singedImage, command=singedcommand)
        singedbutton.grid(row = 7, column = 6)

        sionbutton=Button(window1, image=sionImage, command=sioncommand)
        sionbutton.grid(row = 7, column = 7)

        sivirbutton=Button(window1, image=sivirImage, command=sivircommand)
        sivirbutton.grid(row = 7, column = 8)

        skarnerbutton=Button(window1, image=skarnerImage, command=skarnercommand)
        skarnerbutton.grid(row = 7, column = 9)

        sonabutton=Button(window1, image=sonaImage, command=sonacommand)
        sonabutton.grid(row = 7, column = 10)

        sorakabutton=Button(window1, image=sorakaImage, command=sorakacommand)
        sorakabutton.grid(row = 7, column = 11)

        swainbutton=Button(window1, image=swainImage, command=swaincommand)
        swainbutton.grid(row = 7, column = 12)

        syndrabutton=Button(window1, image=syndraImage, command=syndracommand)
        syndrabutton.grid(row = 7, column = 13)

        tahmkenchbutton=Button(window1, image=tahmkenchImage, command=tahmkenchcommand)
        tahmkenchbutton.grid(row = 7, column = 14)

        taliyahbutton=Button(window1, image=taliyahImage, command=taliyahcommand)
        taliyahbutton.grid(row = 7, column = 15)

        talonbutton=Button(window1, image=talonImage, command=taloncommand)
        talonbutton.grid(row = 8, column = 1)

        taricbutton=Button(window1, image=taricImage, command=tariccommand)
        taricbutton.grid(row = 8, column = 2)

        teemobutton=Button(window1, image=teemoImage, command=teemocommand)
        teemobutton.grid(row = 8, column = 3)
        
        threshbutton=Button(window1, image=threshImage, command=threshcommand)
        threshbutton.grid(row = 8, column = 4)

        tristanabutton=Button(window1, image=tristanaImage, command=tristanacommand)
        tristanabutton.grid(row = 8, column = 5)

        trundlebutton=Button(window1, image=trundleImage, command=trundlecommand)
        trundlebutton.grid(row = 8, column = 6)

        tryndamerebutton=Button(window1, image=tryndamereImage, command=tryndamerecommand)
        tryndamerebutton.grid(row = 8, column = 7)

        twistedfatebutton=Button(window1, image=twistedfateImage, command=twistedfatecommand)
        twistedfatebutton.grid(row = 8, column = 8)

        twitchbutton=Button(window1, image=twitchImage, command=twitchcommand)
        twitchbutton.grid(row = 8, column = 9)

        udyrbutton=Button(window1, image=udyrImage, command=udyrcommand)
        udyrbutton.grid(row = 8, column = 10)

        urgotbutton=Button(window1, image=urgotImage, command=urgotcommand)
        urgotbutton.grid(row = 8, column = 11)

        varusbutton=Button(window1, image=varusImage, command=varuscommand)
        varusbutton.grid(row = 8, column = 12)

        vaynebutton=Button(window1, image=vayneImage, command=vaynecommand)
        vaynebutton.grid(row = 8, column = 13)

        veigarbutton=Button(window1, image=veigarImage, command=veigarcommand)
        veigarbutton.grid(row = 8, column = 14)

        arrowbutton=Button(window1, image=arrowImage, command=buttoncommand)
        arrowbutton.grid(row = 8, column =15)

        window1.mainloop()

class ChooseChampion2:
    def __init__(self):
        window2=Tk()
        window2.geometry("1920x1080+-10+0")
        window2.title("Choose a Champion")

        def velkozcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Vel'Koz"
            health=float(1799.68)
            attackd=float(108.34495076903)
            attacks=float(0.77)
            move=float(340)
            healthr=float(14.774)
            armor=float(81.38)
            magic=float(38.5)
            
        def vicommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Vi"
            health=float(2027.8)
            attackd=float(115.38)
            attacks=float(0.891)
            move=float(340)
            healthr=float(24.312)
            armor=float(94.5)
            magic=float(53.35)
            
        def viktorcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Viktor"
            health=float(1842.01)
            attackd=float(103.04)
            attacks=float(0.894)
            move=float(335)
            healthr=float(18.892)
            armor=float(90.72)
            magic=float(38.5)
            
        def vladimircommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Vladimir"
            health=float(1953)
            attackd=float(106)
            attacks=float(0.882)
            move=float(330)
            healthr=float(17.208)
            armor=float(79.1)
            magic=float(38.5)
            
        def volibearcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Volibar"
            health=float(2046.48)
            attackd=float(115.644)
            attacks=float(0.957)
            move=float(345)
            healthr=float(19.142)
            armor=float(94.5)
            magic=float(53.35)
            
        def warwickcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Warwick"
            health=float(1995)
            attackd=float(109)
            attacks=float(0.887)
            move=float(335)
            healthr=float(16.5)
            armor=float(87.4)
            magic=float(53.35)
            
        def wukongcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Wukong"
            health=float(2022.8)
            attackd=float(114.276)
            attacks=float(0.993)
            move=float(345)
            healthr=float(17.242)
            armor=float(93.5)
            magic=float(53.35)
            
            
        def xerathcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Xerath"
            health=float(1874.4)
            attackd=float(105.7)
            attacks=float(0.77)
            move=float(340)
            healthr=float(14.774)
            armor=float(81.38)
            magic=float(38.5)
            
        def xinzhaocommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Xin Zhao"
            health=float(2164)
            attackd=float(113.644)
            attacks=float(0.997)
            move=float(345)
            healthr=float(20.076)
            armor=float(94.5)
            magic=float(53.35)
            
        def yasuocommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Yasuo"
            health=float(1911.76)
            attackd=float(109.776)
            attacks=float(0.955)
            move=float(345)
            healthr=float(21.812)
            armor=float(87.8)
            magic=float(38.5)
            
        def yorickcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Yorick"
            health=float(2280)
            attackd=float(142)
            attacks=float(0.838)
            move=float(340)
            healthr=float(21.6)
            armor=float(107)
            magic=float(53.35)
            
        def zaccommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Zac"
            health=float(2230)
            attackd=float(117.375)
            attacks=float(0.811)
            move=float(340)
            healthr=float(16.5)
            armor=float(92.5)
            magic=float(53.35)
            
        def zedcommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Zed"
            health=float(1939.4)
            attackd=float(112.512)
            attacks=float(0.883)
            move=float(345)
            healthr=float(18.142)
            armor=float(91.5)
            magic=float(53.35)
            
        def ziggscommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Ziggs"
            health=float(1884.4)
            attackd=float(106.908)
            attacks=float(0.879)
            move=float(325)
            healthr=float(16.458)
            armor=float(77.644)
            magic=float(38.5)
            
        def zileancommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Zilean"
            health=float(1706.28)
            attackd=float(102.64)
            attacks=float(0.851)
            move=float(335)
            healthr=float(13.94)
            armor=float(88.6)
            magic=float(38.5)
                        
        def zyracommand():
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            name="Zyra"
            health=float(1757)
            attackd=float(107.776)
            attacks=float(0.849)
            move=float(340)
            healthr=float(14.19)
            armor=float(80)
            magic=float(38.5)

        def gotochampion1():
            window2.destroy()
            ChooseChampion()

        def gotochooseitem():
            window2.destroy()
            ChooseItem()

        velkozImage=PhotoImage(file ="Velkoz.gif")
        viImage=PhotoImage(file ="Vi.gif")
        viktorImage=PhotoImage(file ="Viktor.gif")
        vladimirImage=PhotoImage(file ="Vladimir.gif")
        volibearImage=PhotoImage(file ="Volibear.gif")
        warwickImage=PhotoImage(file ="Warwick.gif")
        wukongImage=PhotoImage(file ="Wukong.gif")
        xerathImage=PhotoImage(file ="Xerath.gif")
        xinzhaoImage=PhotoImage(file ="XinZhao.gif")
        yasuoImage=PhotoImage(file ="Yasuo.gif")
        yorickImage=PhotoImage(file ="Yorick.gif")
        zacImage=PhotoImage(file ="Zac.gif")
        zedImage=PhotoImage(file ="Zed.gif")
        ziggsImage=PhotoImage(file ="Ziggs.gif")
        zileanImage=PhotoImage(file ="Zilean.gif")
        zyraImage=PhotoImage(file ="Zyra.gif")
        uparrowImage=PhotoImage(file="uparrow.gif")
        arrow2Image=PhotoImage(file="arrow2.gif")

        frame2=Frame(window2).grid()

        canv_2=Canvas(frame2, height=1020, width=1920, bg="gray").grid(row = 1, rowspan = 800, column = 1, columnspan = 1600)

        velkozbutton=Button(window2, image=velkozImage, command=velkozcommand)
        velkozbutton.grid(row = 1, column = 1)

        vibutton=Button(window2, image=viImage, command=vicommand)
        vibutton.grid(row = 1, column = 2)

        viktorbutton=Button(window2, image=viktorImage, command=viktorcommand)
        viktorbutton.grid(row = 1, column = 3)

        vladimirbutton=Button(window2, image=vladimirImage, command=vladimircommand)
        vladimirbutton.grid(row = 1, column = 4)

        volibearbutton=Button(window2, image=volibearImage, command=volibearcommand)
        volibearbutton.grid(row = 1, column = 5)

        warwickbutton=Button(window2, image=warwickImage, command=warwickcommand)
        warwickbutton.grid(row = 1, column = 6)

        wukongbutton=Button(window2, image=wukongImage, command=wukongcommand)
        wukongbutton.grid(row = 1, column = 7)

        xerathbutton=Button(window2, image=xerathImage, command=xerathcommand)
        xerathbutton.grid(row = 1, column = 8)

        xinzhaobutton=Button(window2, image=xinzhaoImage, command=xinzhaocommand)
        xinzhaobutton.grid(row = 1, column = 9)

        yasuobutton=Button(window2, image=yasuoImage, command=yasuocommand)
        yasuobutton.grid(row = 1, column = 10)

        yorickbutton=Button(window2, image=yorickImage, command=yorickcommand)
        yorickbutton.grid(row = 1, column = 11)

        zacbutton=Button(window2, image=zacImage, command=zaccommand)
        zacbutton.grid(row = 1, column = 12)

        zedbutton=Button(window2, image=zedImage, command=zedcommand)
        zedbutton.grid(row = 1, column = 13)

        ziggsbutton=Button(window2, image=ziggsImage, command=ziggscommand)
        ziggsbutton.grid(row = 1, column = 14)

        zileanbutton=Button(window2, image=zileanImage, command=zileancommand)
        zileanbutton.grid(row = 1, column = 15)

        zyrabutton=Button(window2, image=zyraImage, command=zyracommand)
        zyrabutton.grid(row = 2, column = 1)

        uparrowbutton=Button(window2, image=uparrowImage, command=gotochampion1)
        uparrowbutton.grid(row=2, column=2)

        arrow2button=Button(window2, image=arrow2Image, command=gotochooseitem)
        arrow2button.grid(row=2, column=3)

        window2.mainloop()

class ChooseItem:
    def __init__(self):

        window3=Tk() 
        window3.geometry("707x565+550+250")
        window3.title("Choose six items")

        def abyssalmaskcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+350
            magic=magic+55
        def adaptivehelmcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+350
            magic=magic+55
            healthr=healthr+100
        def archangelcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+80
        def ardentcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+60
        def athenescommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            magic=magic+30
            attackd=attackd+30
        def bannercommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            magic=magic+30
            healthr=healthr+125
            armor=armor+60
        def bansheecommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            magic=magic+60
            attackd=attackd+70
        def berserkercommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attacks=attacks+0.35
            move=move+45
        def bladecommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attacks=attacks+0.25
            attackd=attackd+40
        def bloodrazercommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attacks=attacks+0.5
        def bootsofmobilitycommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            move=move+25
        def bootsofswiftnesscommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            move=move+55
        def cinderhulkcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=(health*1.2)+300
        def deadmanscommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+425
            armot=armor+60
        def deathdancecommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+80
        def duskbladecommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+55
        def edgeofknightcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+250
            attackd=attackd+55
        def essencereavercommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+70
        def eyecommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+500
            healthr=healthr*3
        def eyeoftheoasiscommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health+health+200
            healthr+healthr*1.25
        def faceofthemountaincommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            healthr=healthr+450
            healthr=healthr*2
        def frozenmalletcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+700
            attackd=attackd+30
        def gargoylestoneplatecommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            magic=magic+40
            armor=armor+40
        def guardianangelcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            armor=armor+30
            attackd=attackd+40
        def guinsoosragebladecommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+85
            attacks=attacks+.25
        def hextechglpcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+300
            attackd=attackd+80
        def hextechgunbladecommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+120
        def hextechprotobeltcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+300
            attackd=attackd+60
        def iceborncommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            armor=armor+65
        def infinityedgecommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+70
        def ioniancommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            move=move+40
        def knightsvowcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+250
            armor=armor+40
        def liandryscommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+300
            attackd=attackd+80
        def lichbanecommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+80
            move=move*1.07
        def lockettcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            magic=magic+60
            armor=armor+30        
        def lorddominikscommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+50
        def ludenscommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            move=move*1.1
            attackd=attackd+100
        def manamunecommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+25
        def mawcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+25
            magic=magic+45        
        def mercurycommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            magic=magic+25
            move=move+45
        def mikaelcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            magic=magic+40
            move=move*1.15
        def morellonomicommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+100
        def mortalremindercommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+50
        def ninjatabicommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            armor=armor+30
            move=move+45
        def ohmwreckercommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            armor=armor+50
            health=health+300
            healthr=healthr*1.5
        def phantomcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            move=move*1.05
            attacks=attacks*1.45
        def rabadonscommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+120
            attacks=attacks*1.2
        def randuinscommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            armor=armor+60
            health=health+400
        def rapidfirecommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attacks=attacks*1.3
            move=move*1.05
        def ravenoushydracommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            healthr=healthr*2
            attackd=attackd+80
        def redemptioncommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            healthr=healthr*1.5
            health=health+200
        def righteouscommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+400
            armor=armor+30
            healthr=healthr*2
        def rodofagescommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+300
            attackd=attackd+60
        def rubysightstonecommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+500
        def runaanscommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attacks=attacks*1.4
            move=move*1.07
        def runiccommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            move=move*1.07
            attackd=attackd+60
        def rylaiscommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+300
            attackd=attackd+75
        def sorcererscommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            move=move*1.5
        def spirirbuttoncommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+450
            healthr=healthr*2
            magic=magic+55
        def statikkcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attacks=attacks*1.35
            move=move*1.05
        def sterakscommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+450    
        def sunfirecommand():
            global yolo
            global name
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+420
            armor=armor+60
            yolo=yolo+1
        def theblackcleavercommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+80    
            health=health+400    
        def thebloodcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+80    
        def thornmailcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+250
            armor=armor+80
        def titaniccommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            healthr=healthr*2
            health=health+450
            attackd=attackd+35
        def trinitycommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            health=health+250
            attackd=attackd+25
            move=move*1.05
            attacks=attacks+0.4
        def warmongscommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            healthr=healthr*2
            health=health+800
        def warriorcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+60
        def witsendcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            magic=magic+40
            attacks=attacks+0.4
        def youmuuscommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            attackd=attackd+55
        def zekescommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            armor=armor+60
            magic=magic+30
        def zhonyascommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            armor=armor+45
            attackd=attackd+70
        def zzrotcommand():
            global health
            global attackd
            global attacks
            global move
            global healthr
            global armor
            global magic
            armor=armor+55
            magic=magic+55
            healthr=healthr*2.5
        def finishcommand():
            print("The champion you chose is",name,"and they have",health,"health and",healthr,"health regeneration and do"
                  ,attackd,"units of damage at a rate of",attacks,".",name,"has a speed of",move,"and has an armor rating of"
                  ,armor,"and a magic resist rating of",magic,".")

        abyssalmaskImage=PhotoImage(file ="Abyssal_Mask.gif")
        adaptivehelmImage=PhotoImage(file ="0Adaptive_Helm.gif")
        archangelImage=PhotoImage(file ="0Archangel_s_Staff_item.gif")
        ardentImage=PhotoImage(file ="0Ardent_Censer_item.gif")
        athenesImage=PhotoImage(file ="0Athene_s_Unholy_Grail_item.gif")
        bannerImage=PhotoImage(file ="0Banner_of_Command_item.gif")
        bansheesveilImage=PhotoImage(file ="0Banshee_s_Veil_item.gif")
        berserkerImage=PhotoImage(file ="0Berserker_s_Greaves_item.gif")
        bladeImage=PhotoImage(file ="0Blade_of_the_Ruined_King_item.gif")
        bloodrazerImage=PhotoImage(file ="0Bloodrazor_item.gif")
        bootsofmobilityImage=PhotoImage(file ="0Boots_of_Mobility_item.gif")
        bootsofswiftnessImage=PhotoImage(file ="0Boots_of_Swiftness_item.gif")
        cinderhulkImage=PhotoImage(file ="0Cinderhulk_item.gif")
        deadmansplateImage=PhotoImage(file ="0dead_mans_plate.gif")
        deathsdanceImage=PhotoImage(file ="0deaths_dance.gif")
        duskbladeImage=PhotoImage(file ="0duskblade.gif")
        edgeofknightImage=PhotoImage(file ="0edgeofknight.gif")
        essencereaverImage=PhotoImage(file ="0Essence_Reaver_item.gif")
        eyeImage=PhotoImage(file ="0eye.gif")
        eyeoftheoasisImage=PhotoImage(file ="0eye_of_the_oasis.gif")
        faceofthemountainImage=PhotoImage(file ="0face_of_the_mountain.gif")
        frozenmalletImage=PhotoImage(file ="0Frozen_Mallet_item.gif")
        gargoylestoneplateImage=PhotoImage(file ="0gargoyle_stoneplate.gif")
        guardianangelImage=PhotoImage(file ="0Guardian_Angel_item.gif")
        guinsoosragebladeImage=PhotoImage(file ="0Guinsoo_s_Rageblade_item.gif")
        hextechglpImage=PhotoImage(file ="0Hextech_GLP-800_item.gif")
        hextechgunbladeImage=PhotoImage(file ="0Hextech_Gunblade_item.gif")
        hextechprotobeltImage=PhotoImage(file ="0Hextech_Protobelt-01_item.gif")
        iceborngauntletImage=PhotoImage(file ="0Iceborn_Gauntlet_item.gif")
        infinityedgeImage=PhotoImage(file ="0Infinity_edge_item.gif")
        ionianbootsImage=PhotoImage(file ="0Ionian_Boots_of_Lucidity_item.gif")
        knightsvowImage=PhotoImage(file ="0knights_vow.gif")
        liandrystormentImage=PhotoImage(file ="0Liandry_s_Torment_item.gif")
        lichbaneImage=PhotoImage(file ="0Lich_Bane_item.gif")
        locketImage=PhotoImage(file ="0Locket_of_the_Iron_Solari_item.gif")
        lorddominiksImage=PhotoImage(file ="0lord_dominiks.gif")
        ludensechoImage=PhotoImage(file ="0Luden_s_Echo_item.gif")
        manamuneImage=PhotoImage(file ="0Manamune_item.gif")
        mawImage=PhotoImage(file ="0maw.gif")
        mercurystreadsImage=PhotoImage(file ="0Mercury_s_Treads_item.gif")
        mikaelsImage=PhotoImage(file ="0Mikael_s_Crucible_item.gif")
        morellonomiconImage=PhotoImage(file ="0Morellonomicon_item.gif")
        mortalreminderImage=PhotoImage(file ="0mortal_reminder.gif")
        ninjatabiImage=PhotoImage(file ="0Ninja_Tabi_item.gif")
        ohmwreckerImage=PhotoImage(file ="0Ohmwrecker_item.gif")
        phantomdancerImage=PhotoImage(file ="0phantom_dancer.gif")
        rabadonsImage=PhotoImage(file ="0Rabadon_s_Deathcap_item.gif")
        randuinsImage=PhotoImage(file ="0Randuin_s_Omen_item.gif")
        rapidfirecannonImage=PhotoImage(file ="0rapid_firecannon.gif")
        ravenoushydraImage=PhotoImage(file ="0ravenous_hydra.gif")
        redemptionImage=PhotoImage(file ="0redemption.gif")
        righteousgloryImage=PhotoImage(file ="0Righteous_Glory_item.gif")
        rodofagesImage=PhotoImage(file ="0Rod_of_Ages_item.gif")
        rubysightstoneImage=PhotoImage(file ="0Ruby_Sightstone_item.gif")
        runaanshurricaneImage=PhotoImage(file ="0Runaan_s_Hurricane_item.gif")
        runicechoesImage=PhotoImage(file ="0Runic_Echoes_item.gif")
        rylaisImage=PhotoImage(file ="0Rylais.gif")
        sorcerersshoesImage=PhotoImage(file ="0Sorcerer_s_Shoes_item.gif")
        spiritvisageImage=PhotoImage(file ="0Spirit_Visage_item.gif")
        statikkshivImage=PhotoImage(file ="0Statikk_Shiv_item.gif")
        steraksgageImage=PhotoImage(file ="0Sterak_s_Gage_item.gif")
        sunfirecapeImage=PhotoImage(file ="0Sunfire_Cape_item.gif")
        theblackcleaverImage=PhotoImage(file ="0the_black_cleaver.gif")
        thebloodthirsterImage=PhotoImage(file ="0The_Bloodthirster_item.gif")
        thornmailImage=PhotoImage(file ="0thornmail.gif")
        titanichydraImage=PhotoImage(file ="0titanic_hydra.gif")
        trinityforceImage=PhotoImage(file ="0Trinity_Force_item.gif")
        warmogsarmorImage=PhotoImage(file ="0Warmog_s_Armor_item.gif")
        warriorImage=PhotoImage(file ="0Warrior_item.gif")
        witsendImage=PhotoImage(file ="0Wit_s_End_item.gif")
        youmuusghostbladeImage=PhotoImage(file ="0youmuus_ghostblade.gif")
        zekesconvergenceImage=PhotoImage(file ="0Zeke_s_Convergence_item.gif")
        zhonyasImage=PhotoImage(file ="0Zhonya_s_Hourglass_item.gif")
        zzrotportalImage=PhotoImage(file ="0zzrot_portal.gif")
        finishImage=PhotoImage(file="finish64.gif")

        frame3=Frame(window3).grid()

        canv_3=Canvas(frame3, height=1020, width=1920, bg="gray").grid(row = 1, rowspan = 800, column = 1, columnspan = 1600)
   

        abyssalmaskbutton=Button(window3, image=abyssalmaskImage, command=abyssalmaskcommand)
        abyssalmaskbutton.grid(row = 1, column = 1)

        adaptivehelmbutton=Button(window3, image=adaptivehelmImage, command=adaptivehelmcommand)
        adaptivehelmbutton.grid(row = 1, column = 2)

        archangelbutton=Button(window3, image=archangelImage, command=archangelcommand)
        archangelbutton.grid(row = 1, column = 3)
        
        ardentbutton=Button(window3, image=ardentImage, command= ardentcommand)
        ardentbutton.grid(row = 1, column = 4)

        athenesbutton=Button(window3, image=athenesImage, command=athenescommand)
        athenesbutton.grid(row = 1, column = 5)

        bannerbutton=Button(window3, image=bannerImage, command=bannercommand)
        bannerbutton.grid(row = 1, column = 6)

        bansheebutton=Button(window3, image=bansheesveilImage, command=bansheecommand)
        bansheebutton.grid(row = 1, column = 7)

        berserkerbutton=Button(window3, image=berserkerImage, command=berserkercommand)
        berserkerbutton.grid(row = 1, column = 8)

        bladebutton=Button(window3, image=bladeImage, command=bladecommand)
        bladebutton.grid(row = 1, column = 9)

        bloodrazerbutton=Button(window3, image=bloodrazerImage, command=bloodrazercommand)
        bloodrazerbutton.grid(row = 1, column = 10)





        

        bootsofmobilitybutton=Button(window3, image=bootsofmobilityImage, command=bootsofmobilitycommand)
        bootsofmobilitybutton.grid(row = 2, column = 1)

        bootsofswiftnessbutton=Button(window3, image=bootsofswiftnessImage, command=bootsofswiftnesscommand)
        bootsofswiftnessbutton.grid(row = 2, column = 2)

        cinderhulkbutton=Button(window3, image=cinderhulkImage, command=cinderhulkcommand)
        cinderhulkbutton.grid(row = 2, column = 3)

        deadmansbutton=Button(window3, image=deadmansplateImage, command=deadmanscommand)
        deadmansbutton.grid(row = 2, column = 4)

        deathsdancebutton=Button(window3, image=deathsdanceImage, command=deathdancecommand)
        deathsdancebutton.grid(row = 2, column = 5)

        duskbladebutton=Button(window3, image=duskbladeImage, command=duskbladecommand)
        duskbladebutton.grid(row = 2, column = 6)

        edgeofknightbutton=Button(window3, image=edgeofknightImage, command=edgeofknightcommand)
        edgeofknightbutton.grid(row = 2, column = 7)

        essencereaverbutton=Button(window3, image=essencereaverImage, command=essencereavercommand)
        essencereaverbutton.grid(row = 2, column = 8)

        eyebutton=Button(window3, image=eyeImage, command=eyecommand)
        eyebutton.grid(row = 2, column = 9)

        eyeoftheoasisbutton=Button(window3, image=eyeoftheoasisImage, command=eyeoftheoasiscommand)
        eyeoftheoasisbutton.grid(row = 2, column = 10)




        

        faceofthemountainbutton=Button(window3, image=faceofthemountainImage, command=faceofthemountaincommand)
        faceofthemountainbutton.grid(row = 3, column = 1)

        frozenmalletbutton=Button(window3, image=frozenmalletImage, command=frozenmalletcommand)
        frozenmalletbutton.grid(row = 3, column = 2)

        gargoylestoneplatebutton=Button(window3, image=gargoylestoneplateImage, command=gargoylestoneplatecommand)
        gargoylestoneplatebutton.grid(row = 3, column = 3)

        guardianangelbutton=Button(window3, image=guardianangelImage, command=guardianangelcommand)
        guardianangelbutton.grid(row = 3, column = 4)
        
        guinsoosragebladebutton=Button(window3, image=guinsoosragebladeImage, command=guinsoosragebladecommand)
        guinsoosragebladebutton.grid(row = 3, column = 5)

        hextechglpbutton=Button(window3, image=hextechglpImage, command=hextechglpcommand)
        hextechglpbutton.grid(row = 3, column = 6)

        hextechgunbladebutton=Button(window3, image=hextechgunbladeImage, command=hextechgunbladecommand)
        hextechgunbladebutton.grid(row = 3, column = 7)

        hextechprotobeltbutton=Button(window3, image=hextechprotobeltImage, command=hextechprotobeltcommand)
        hextechprotobeltbutton.grid(row = 3, column = 8)

        icebornbutton=Button(window3, image=iceborngauntletImage, command= iceborncommand)
        icebornbutton.grid(row = 3, column = 9)

        infinityedgebutton=Button(window3, image=infinityedgeImage, command=infinityedgecommand)
        infinityedgebutton.grid(row = 3, column = 10)


        

        ionianbutton=Button(window3, image=ionianbootsImage, command=ioniancommand)
        ionianbutton.grid(row = 4, column = 1)

        knightsvowbutton=Button(window3, image=knightsvowImage, command=knightsvowcommand)
        knightsvowbutton.grid(row = 4, column = 2)

        liandrysbutton=Button(window3, image=liandrystormentImage, command=liandryscommand)
        liandrysbutton.grid(row = 4, column = 3)

        lichbanebutton=Button(window3, image=lichbaneImage, command=lichbanecommand)
        lichbanebutton.grid(row = 4, column = 4)

        locketbutton=Button(window3, image=locketImage, command=lockettcommand)
        locketbutton.grid(row = 4, column = 5)

        lorddominiksbutton=Button(window3, image=lorddominiksImage, command=lorddominikscommand)
        lorddominiksbutton.grid(row = 4, column = 6)

        ludensbutton=Button(window3, image=ludensechoImage, command=ludenscommand)
        ludensbutton.grid(row = 4, column = 7)

        manamunebutton=Button(window3, image=manamuneImage, command=manamunecommand)
        manamunebutton.grid(row = 4, column = 8)

        mawbutton=Button(window3, image=mawImage, command=mawcommand)
        mawbutton.grid(row = 4, column = 9)

        mercurybutton=Button(window3, image=mercurystreadsImage, command=mercurycommand)
        mercurybutton.grid(row = 4, column = 10)



        

        mikaelbutton=Button(window3, image=mikaelsImage, command=mikaelcommand)
        mikaelbutton.grid(row = 5, column = 1)

        morellonomiconbutton=Button(window3, image=morellonomiconImage, command=morellonomicommand)
        morellonomiconbutton.grid(row = 5, column = 2)

        mortalreminderbutton=Button(window3, image=mortalreminderImage, command=mortalremindercommand)
        mortalreminderbutton.grid(row = 5, column = 3)

        ninjatabibutton=Button(window3, image=ninjatabiImage, command=ninjatabicommand)
        ninjatabibutton.grid(row = 5, column = 4)

        ohmwreckerbutton=Button(window3, image=ohmwreckerImage, command=ohmwreckercommand)
        ohmwreckerbutton.grid(row = 5, column = 5)

        phantombutton=Button(window3, image=phantomdancerImage, command=phantomcommand)
        phantombutton.grid(row = 5, column = 6)

        rabadonsbutton=Button(window3, image=rabadonsImage, command=rabadonscommand)
        rabadonsbutton.grid(row = 5, column = 7)

        randuinsbutton=Button(window3, image=randuinsImage, command=randuinscommand)
        randuinsbutton.grid(row = 5, column = 8)

        rapidfirebutton=Button(window3, image=rapidfirecannonImage, command=rapidfirecommand)
        rapidfirebutton.grid(row = 5, column = 9)

        ravenoushydrabutton=Button(window3, image=ravenoushydraImage, command=ravenoushydracommand)
        ravenoushydrabutton.grid(row = 5, column = 10)



        

        redemptionbutton=Button(window3, image=redemptionImage, command=redemptioncommand)
        redemptionbutton.grid(row = 6, column = 1)

        righteousbutton=Button(window3, image=righteousgloryImage, command=righteouscommand)
        righteousbutton.grid(row = 6, column = 2)

        rodofagesbutton=Button(window3, image=rodofagesImage, command=rodofagescommand)
        rodofagesbutton.grid(row = 6, column = 3)

        rubysightstonebutton=Button(window3, image=rubysightstoneImage, command=rubysightstonecommand)
        rubysightstonebutton.grid(row = 6, column = 4)

        runaansbutton=Button(window3, image=runaanshurricaneImage, command=runaanscommand)
        runaansbutton.grid(row = 6, column = 5)

        runicbutton=Button(window3, image=runicechoesImage, command=runiccommand)
        runicbutton.grid(row = 6, column = 6)

        rylaisbutton=Button(window3, image=rylaisImage, command=rylaiscommand)
        rylaisbutton.grid(row = 6, column = 7)

        sorcerersbutton=Button(window3, image=sorcerersshoesImage, command=sorcererscommand)
        sorcerersbutton.grid(row = 6, column = 8)

        spiritbutton=Button(window3, image=spiritvisageImage, command=spirirbuttoncommand)
        spiritbutton.grid(row = 6, column = 9)

        statikkbutton=Button(window3, image=statikkshivImage, command=statikkcommand)
        statikkbutton.grid(row = 6, column = 10)





        

        steraksbutton=Button(window3, image=steraksgageImage, command=sterakscommand)
        steraksbutton.grid(row = 7, column = 1)

        sunfirebutton=Button(window3, image=sunfirecapeImage, command=sunfirecommand)
        sunfirebutton.grid(row = 7, column = 2)

        theblackcleaverbutton=Button(window3, image=theblackcleaverImage, command=theblackcleavercommand)
        theblackcleaverbutton.grid(row = 7, column = 3)

        thebloodbutton=Button(window3, image=thebloodthirsterImage, command=thebloodcommand)
        thebloodbutton.grid(row = 7, column = 4)

        thornmailbutton=Button(window3, image=thornmailImage, command=thornmailcommand)
        thornmailbutton.grid(row = 7, column = 5)

        titanicbutton=Button(window3, image=titanichydraImage, command=titaniccommand)
        titanicbutton.grid(row = 7, column = 6)

        trinitybutton=Button(window3, image=trinityforceImage, command=trinitycommand)
        trinitybutton.grid(row = 7, column = 7)

        warmogsbutton=Button(window3, image=warmogsarmorImage, command=warmongscommand)
        warmogsbutton.grid(row = 7, column = 8)

        warriorbutton=Button(window3, image=warriorImage, command=warriorcommand)
        warriorbutton.grid(row = 7, column = 9)

        witsendbutton=Button(window3, image=witsendImage, command=witsendcommand)
        witsendbutton.grid(row = 7, column = 10)

        youmuusbutton=Button(window3, image=youmuusghostbladeImage, command=youmuuscommand)
        youmuusbutton.grid(row = 8, column = 1)

        zekesbutton=Button(window3, image=zekesconvergenceImage, command=zekescommand)
        zekesbutton.grid(row = 8, column = 2)

        zhonyasbutton=Button(window3, image=zhonyasImage, command=zhonyascommand)
        zhonyasbutton.grid(row = 8, column = 3)

        zzrotbutton=Button(window3, image=zzrotportalImage, command=zzrotcommand)
        zzrotbutton.grid(row = 8, column = 4)

        finishbutton=Button(window3, image=finishImage, command=finishcommand)
        finishbutton.grid(row=8, column=5)
        
        window3.mainloop()
ChooseChampion()
